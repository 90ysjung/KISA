﻿#*- coding: utf-8 -*-
import konlpy
from konlpy.tag import Twitter
import nltk
import pickle
import numpy
from numpy._distributor_init import NUMPY_MKL
import operator
from gensim import corpora, models
import gensim
import math
from collections import Counter
import os, re, copy
import sys
import io
import matplotlib.pyplot as plt
import pytagcloud

twitter = Twitter()

input_path = "C:\\ysjung\\KISA\\data\\autofocus"
doc_list_tmp = os.listdir(input_path)

doc_list_ext = []          # full name
doc_list = []              # name만(확장자 빼고)
for i in doc_list_tmp:
     ext = os.path.splitext(i)[-1]
     # 확장자별로 이름만 가져온다
     if ext == '.csv':
         doc_list_ext.append(i)
         doc_list.append(os.path.splitext(i)[0])

#print(doc_list)
#print(doc_list_ext)


# 모든 문서별 tokens(list)를 list 로 생성
# 한 row 가 1 list 로 나와야 한다 
docs = []
for i in doc_list_ext:
    with io.open(input_path + "\\" + i, 'r', encoding='utf8') as file:
        data = file.read()

    mal_tmp = data.split()
    docs.append(mal_tmp) 

#print(docs) 
#print(type(docs)) 

word_dict = []
for j in docs:                # 한개 list 읽어서
    for k in j:               # 리스트에 한 요소 읽어서
        tmp = k.split(',')    # ',' 로 짤라서
        word_dict.append(tmp) # 리스트에 저장 

#word_dict = word_dict.split(',')
print(word_dict)
print(type(word_dict))


# 문서별 모든 tokens 를 하나의 list 로 생성


