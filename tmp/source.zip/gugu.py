'''
for i in range(2,10):
    gugudan = []
    for j in range(1,10):
        gugudan.append(i* j)
    print(gugudan)
'''

'''
num = [3,6,9,12]
for i in num:
    result = []
    if i % 2 == 0:
        result.append(i * 3)
        print(result, end='')
    else:
        print('')
'''



