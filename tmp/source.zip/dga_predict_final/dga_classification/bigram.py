import dga_classification.data_generator as data

from keras.layers.core import Dense
from keras.models import Sequential

import sklearn
from sklearn import feature_extraction
from sklearn.metrics import classification_report
# from sklearn.cross_validation import train_test_split
from sklearn.model_selection import train_test_split


def build_model(max_features):
    """Builds logistic regression model"""
    model = Sequential()
    model.add(Dense(1, input_dim=max_features, activation='sigmoid'))

    model.compile(loss='binary_crossentropy', optimizer='adam')

    return model


def run(max_epoch=50, nfolds=10, batch_size=128):

    # DATA 생성
    indata = data.get_data()

    # Extract data and labels
    # X = [x[1] for x in indata]
    # labels = [z[0] for z in indata]
    # X = [x[1] for x in indata]

    # X: URL 정보
    # labels: 레이블 정보 (생성 DGA 이름)
    X = []
    labels = []

    for a in indata:
        X.append(a[1])
        labels.append(a[0])

    # Create feature vectors
    print('Vectorizing data...')
    # CountVectorizer: 문서의 집합으로부터 단어의 수를 세어 BOW 벡터를 만든다.
    # analyzer: char --> 문자의 n-gram
    # ngram_range: (min_n, max_n) n-gram 범위
    ngram_vectorizer = feature_extraction.text.CountVectorizer(analyzer='char', ngram_range=(2, 2))
    count_vec = ngram_vectorizer.fit_transform(X)

    max_features = count_vec.shape[1]

    # Covert labels to 0-1
    y = [0 if x == 'benign' else 1 for x in labels]

    final_data = []

    for fold in range(nfolds):
        print('fold %u/%u' % (fold+1, nfolds))
        X_train, X_test, y_train, y_test, _, label_test = train_test_split(count_vec, y, labels, test_size=0.2)

        print(X_train.shape)
        print(X_test.shape)
        print(len(label_test))

        print('Build model...')
        model = build_model(max_features)

        print('Train...')
        X_train, X_holdout, y_train, y_holdout = train_test_split(X_train, y_train, test_size=0.05)
        best_iter = -1
        best_auc = 0.0
        out_data = {}

        for ep in range(max_epoch):
            model.fit(X_train.todense(), y_train, batch_size=batch_size, epochs=1)

            t_probs = model.predict_proba(X_holdout.todense())
            t_auc = sklearn.metrics.roc_auc_score(y_holdout, t_probs)
            t_accuracy = sklearn.metrics.accuracy_score(y_holdout, t_probs > .5)
            t_precision = sklearn.metrics.precision_score(y_holdout, t_probs > .5)
            t_recall = sklearn.metrics.recall_score(y_holdout, t_probs > .5)

            print('Epoch %d: auc = %f (best=%f), accuracy = %f, precision = %f, recall = %f' %
                  (ep, t_auc, best_auc, t_accuracy, t_precision, t_recall))
            # print('Epoch %d: auc = %f (best=%f)' % (ep, t_auc, best_auc))
            # print(classification_report(y_holdout, t_probs))

            if t_auc > best_auc:
                best_auc = t_auc
                best_iter = ep

                probs = model.predict_proba(X_test.todense())

                out_data = {'y':y_test, 'labels': label_test, 'probs':probs, 'epochs': ep,
                            'confusion_matrix': sklearn.metrics.confusion_matrix(y_test, probs > .5)}

                # print(sklearn.metrics.confusion_matrix(y_test, probs > .5))
                print('confusion matrix : ', sklearn.metrics.confusion_matrix(y_test, probs > .5))

            else:
                # No longer improving...break and calc statistics
                if (ep-best_iter) > 5:
                    break

        final_data.append(out_data)

    return final_data
''''''

run(nfolds=1)