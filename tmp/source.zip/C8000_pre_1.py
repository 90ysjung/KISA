##################################
# Preprocessing
##################################

from konlpy.tag import Twitter
import re
import io

# reload(sys)
twitter = Twitter()

#with io.open("D:/YSJUNG/TMP/Word2Vec_data_tmp1.TXT", 'r', encoding='utf8') as file:
#data = file.read()

data = ("이전에$conrtibute$ 쓰던 SK사에서의//n&인터넷& |999| 약정기간이 3다6되9어 ㅋㅋㅋ")

print(data)
print(type(data))  # str

'''
#영문 숫자 제거 -> re.sub() 사용
data = re.sub('[0-9|a-z|A-Z|\\s]', '', data) ## \\s -> 공백 제거
print(data)

#특정 문자 replace -> replase() 함수(UTF8)
#data = data.replace("SK","") / translate() 도 있음
'''

#한글만 추출   
data_han = re.compile('[^ ㄱ-ㅣ가-힣]+') # 한글과 띄어쓰기를 제외한 모든 글자(필터 조건)
# hangul = re.compile('[^ \u3131-\u3163\uac00-\ud7a3]+') # 위와 동일(utf8)

result_o = data_han.sub('', data) # 한글과 띄어쓰기를 제외한 모든 부분을 제거
print(result_o)
print(type(result_o))

result_x = data_han.findall(data) # 정규식에 일치되는 부분을 리스트 형태로 저장(빠지는 것들)
print(result_x)
print(type(result_x))

tokens = twitter.pos(result_o)        # pos tagging

print(tokens)
print(type(tokens))

for i in tokens:
    print(i.keys())

'''
## 불용어 모델링

tokens = twitter.morphs(result_o)    # 형태소 추출
#tokens = twitter.pos(tokens)        # pos tagging
#tokens = twitter.nouns(str(tokens)) # 명사 추출
'''

'''
print(tokens)
print(len(data), len(tokens))
print(len(set(data)), len(set(tokens))) ## 동일 단어 중복 제거

'''

## 토픽 모델링

## Word embedding

############################################
## CNN
############################################