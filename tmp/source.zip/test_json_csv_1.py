﻿import json
import csv
import os, re

#BASE_DIR = os.path.dirname(os.path.abspath(__file__)) + '\\data'
BASE_DIR = 'C:\ysjung\KISA\data' + '\\'
# file_name = 'COLLECT_C0001.json'
file_name = 'COLLECT_C8000_5.json'


def read_json_file(directory, file_name):
    """ 디렉토리 명과 파일 명을 입력 받아 해당 파일을 JSON 객체로 반환하는  함수 """
    with open(os.path.join(directory, file_name), 'r', encoding='UTF8') as data_file:
        data = json.load(data_file)    ## loads()...?
    return data


def get_keys(file_name):
    data = read_json_file(BASE_DIR, file_name)

#    keys = [key for key in data[0]]
#    keys = data[0].keys()
    for key in data:
        if isinstance(key, dict):
            print(key.keys())
        else:
            print(key)
#    print(key)

def json_to_cvs_all_data(file_name):
    """ JSON 파일 정보를 읽어서 필요한 정보를 CSV 파일로 저장하는 함수 
        예외처리를 위해서 JSON 구조에 맞춰 각각의 요소들을 분석해야 한다. 
    """
    
    # JSON 파일 정보 읽기
    json_data = read_json_file(BASE_DIR, file_name)
    print(len(json_data))
    result_list = []

    for item in json_data:
        id_string = item['_id']['$oid']
        print(id_string) 


json_to_cvs_all_data(file_name)
