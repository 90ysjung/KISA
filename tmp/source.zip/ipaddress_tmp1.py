﻿######################################
# 로컬ip 찾기
import socket
import ipaddress

'''
def get_ipaddress():
  s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
  s.connect(("google.com",80))
  r = s.getsockname()[0]
  s.close()
  return r
  
t = get_ipaddress()
print(t)
'''

######################################
# whois 정보 활용 방안



######################################
# geoip 정보 활용 방안
import json
from urllib.request import urlopen

def getCountry(ipAddress):
    if __name__ == '__main__':
        response = urlopen("http://freegeoip.net/json/"+ipAddress).read().decode('utf-8')
        responseJson = json.loads(response)
        return responseJson.get("country_code")


t = getCountry("125.78.253.58")
print(t)

