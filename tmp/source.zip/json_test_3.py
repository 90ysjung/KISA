# json.decoder.JSONDecodeError: Extra data: line 2 column 1 (char 1543)
# mongoexport 에서 --jsonArray 옵션으로 내리면 위 에러 없음 ex) [{},{},{},...]

### 파이썬으로 json 파일을 읽어온다
### 1 collection 당 1 json 으로 내려온다
##################################
### key 값을 추출
##################################
import json
from pprint import pprint
from collections import OrderedDict   # object_pairs_hook=OrderedDict 는 초기 json 순서대로 찍는다

path = 'C:\ysjung\KISA\data'
input_file = 'COLLECT_C8000.json'

json_data = open(path + '\\' + input_file, encoding='utf-8').read() # str type
doc = json.loads(json_data, object_pairs_hook=OrderedDict)          # object_pairs_hook=OrderedDict

#print(type(doc))           # list로 생성된다

element = len(list(doc))    # mongodb 에서 document 개수
print('\n' + 'Element count: ' + str(element) + '\n')

#key = list((doc[0]))        # key = (doc[0].keys())) 와 차이점은...?


### document 별로 key 값 추출
count = 0
doc_keys = {}
while count <= element - 1:
    key = list((doc[count]))
    doc_keys[count] = key
    count += 1

pprint(doc_keys)
print('')


###################################################
### 모든 dict 의 key 개수가 동일한지 검증
###################################################
count = 0
doc_num = {}
while count <= element -1:
    c = len(list(doc[count]))
    doc_num[count] = c
    count += 1

pprint(doc_num)
print('')


'''
count = 0
result = []
while count < element:
    a = len(list(doc[count]))
    result.append(a)
    count += 1

print(result)
'''

'''

###################################
### 각 key별 value를 추출한다
### 결과물을 write 한다
###################################
print(key)              # key 값 출력

t =


# Write JSON
with open('gfriend.json', 'w', encoding="utf-8") as make_file:
    json.dump(group_data, make_file, ensure_ascii=False, indent=" ")

# Write CSV
f = open('output.csv', 'w', encoding='utf-8', newline='')
wr = csv.writer(f)        ### wr = csv.writer(f, delimiter='\t')
wr.writerow([1, "name_1", False])
wr.writerow([2, "name_2", True])
f.close()

'''

