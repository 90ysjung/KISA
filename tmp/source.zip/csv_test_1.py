'''
import csv

path = 'D:\\py_test\\data'
input_file = 'date_C0001.csv'

csv_file = open(path + "\\" + input_file, 'rb')
reader = csv.reader(csv_file)

for i in reader:
    print(i)

'''

import json

#path = "D:\py_test\data"
#input_file = "test_1.json"

path = "D:\\py_test\\data\\kisa_test"
input_file = "date_C0001.json"

json_data = open(path + "\\" + input_file).read()
data = json.loads(json_data)     ## object_pairs_hook=OrderedDict

for i in data:
    print(i)

