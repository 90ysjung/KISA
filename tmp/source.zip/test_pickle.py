import pickle

path = 'C:\ysjung\KISA\source\dga\dga_classification\data'
file = 'result.pkl'

with open(path + '\\' + file, 'rb') as f:
    data = pickle.load(f)

print(data)
print(type(data))



##################
# DARPA 1999 데이터
# PESIM 2005 데이터
##################

