﻿import csv
import json
import os

BASE_DIR = 'C:\ysjung\KISA\data' + '\\'
file_name = 'COLLECT_C8000.json'

with open(os.path.join(BASE_DIR, file_name), 'r', encoding='UTF8') as data_file:
    data = json.load(data_file)    ## loads() or load() ...?

'''
#f = csv.writer(open('C8000_level_1.csv', 'w'))
#
#Write CSV Header
#f.writerow(["id", "date", "offset", "path", "channel"])
######################################
for x in data :
    f.writerow([x["date"]["$date"],
                x["offset"],
                x["path"],
                x["channel"],
              #  x["ctex:externals"]["ctex:title"],
              #  x["ctex:externals"]["ctex:method"],
              #  x["ctex:externals"]["ctex:channel"],
              #  x["ctex:externals"]["ctex:source"],
                x["_id"]["$oid"]
              #  x["ctex:externals"]["ctex:external"]["ctex:version"],
              #  x["ctex:externals"]["ctex:external"]["ctex:title"],
              #  x["ctex:externals"]["ctex:external"]["ctex:method"],
              #  x["ctex:externals"]["ctex:external"]["ctex:channel"],
              #  x["ctex:externals"]["ctex:external"]["ctex:source"],
              #  x["ctex:externals"]["ctex:external"]["ctex:comment"],
              #  x["ctex:externals"]["ctex:external"]["ctex:external"]
               ])

########################################

#print(type(x))   dict

'''

r = []
n = 'N/A'
for x in data:
    r.append(x["date"]["$date"])
    r.append(x["offset"])
    r.append(x["path"])
    r.append(x["channel"])
    externals = x.get("ctex:externals", n)
    if externals == n:
        r.append(n)   ## 하위 필드 개수..?
    else:
        title = externals.get("ctex:title", n)        # ctex:externals/ctex:title
        if title == n:
            r.append(n)
        else:
            r.append(x["ctex:externals"]["ctex:title"])
        method = externals.get("ctex:method", n)          # ctex:externals/ctex:method
        if method == n:
            r.append(n)
        else:
            r.append(x["ctex:externals"]["ctex:method"])
        channel = externals.get("ctex:method", n)         # ctex:externals/ctex:channel
        if channel == n:
            r.append(n)
        else:
            r.append(x["ctex:externals"]["ctex:channel"])
        source = externals.get("ctex:method", n)          # ctex:externals/ctex:source
        if source == n:
            r.append(n)
        else:
            r.append(x["ctex:externals"]["ctex:source"])
        r.append(x["_id"]["$oid"])
        external = externals.get("ctex:external", n)      # ctex:externals/ctex:external  ### 리스트 식별
        if external == n :
            r.append(n)
# external 가 List 인지 Dictionary 인지 체크 >> List 일 경우 반복처리
        elif isinstance(external, list):
            for external_val in external:
                e_version =  external_val.get("ctex:version", n)   # ctex:externals/ctex:external/ctex:version
                if e_version == n:
                    r.append(n)
                else:
                    r.append(x["ctex:externals"]["ctex:external"]["ctex:version"])
                e_title =  external_val.get("ctex:title", n)       # ctex:externals/ctex:external/ctex:title
                if e_title == n:
                    r.append(n)
                else:
                    r.append(x["ctex:externals"]["ctex:external"]["ctex:title"])
                e_method = external_val.get("ctex:method", n)     # ctex:externals/ctex:external/ctex:method
                if e_method == n:
                    r.append(n)
                else:
                    r.append(x["ctex:externals"]["ctex:external"]["ctex:method"])

print(r)

