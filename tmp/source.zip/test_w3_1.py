﻿'''
import csv
import json
import os

BASE_DIR = 'C:\ysjung\KISA\data' + '\\'
file_name = 'COLLECT_C8000_5.json'

with open(os.path.join(BASE_DIR, file_name), 'r', encoding='UTF8') as data_file:
    data = json.load(data_file)    ## loads() or load() ...?

data = list(data[0])

print(data)

print(type(data))   # dict
'''

import json
import csv
import os, re

BASE_DIR = os.path.dirname(os.path.abspath(__file__)) + '\\data'
# file_name = 'COLLECT_C0001.json'
# file_name = 'COLLECT_C8000.json'

print(BASE_DIR)

