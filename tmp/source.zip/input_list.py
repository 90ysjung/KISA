### 파일 리스트 가져오기
# python input_list.py

import os

path = 'D:\py_test\source'
files = os.listdir(path)

#print(files, end='')
#print('')

for i in files:
   input_list = []
   if '.json' in i:
      input_list.append(path + '\\' + i)
      print(input_list)

'''
print('')
 
for i in files:
   if '.json' in i:
      input_list = path + '\\' + i
      print(input_list, end='')
'''

### 2개 결과 차이점
### 모듈화

for i in input_list:
   print(i)
