import json
import os

BASE_DIR = 'C:\ysjung\KISA\data' + '\\'
#file_name = 'COLLECT_C0001.json'
file_name = 'COLLECT_C8000.json'

def read_json_file(directory, file_name):
### 디렉토리 명과 파일 명을 입력 받아 해당 파일을 JSON 객체로 반환하는  함수
    with open(os.path.join(directory, file_name), 'r', encoding='UTF8') as data_file:
        data = json.load(data_file)    ## loads()...?
    return data

def print_all_items(file_name):
### 파라메터로 받은 파일명의 파일을 분석해서 해당 내용을 모두 출력
    data = read_json_file(BASE_DIR, file_name)

    for values in data:
        print('======================================= start =========================================')
        # _id {1}
        print('* _id : ')
        print('\t$oid : ', values['_id']['$oid'])

        # ctex:externals {12}
        print('* ctex:externals : ')
        print('\tctex:version : ', values['ctex:externals']['ctex:version'])
        print('\tctex:title : ', values['ctex:externals']['ctex:title'])
        print('\tctex:when : ')
        print('\t\tctex:date : ', values['ctex:externals']['ctex:when']['ctex:date'])
        print('\t\tctex:time : ', values['ctex:externals']['ctex:when']['ctex:time'])
        print('\tctex:method : ', values['ctex:externals']['ctex:method'])
        print('\tctex:channel : ', values['ctex:externals']['ctex:channel'])
        print('\tctex:source : ', values['ctex:externals']['ctex:source'])
        print('\tctex:report : ')
        print('\t\tctex:path : ', values['ctex:externals']['ctex:report']['ctex:path'])
        print('\t\tctex:item : ', values['ctex:externals']['ctex:report']['ctex:item'])
        print('\t\tctex:caption : ', values['ctex:externals']['ctex:report']['ctex:caption'])
        print('\t\t@compress : ', values['ctex:externals']['ctex:report']['@compress'])
        print('\tctex:comment : ', values['ctex:externals']['ctex:comment'])

        ### 리스트로 들어 옴[34], field 유동적이라 마지막에...  
        # print('\tctex:external : ', values['ctex:externals'][ctex:externall'])
        print('\t@xmlns:ctex : ', values['ctex:externals']['@xmlns:ctex'])
        print('\t@xmlns:xsi : ', values['ctex:externals']['@xmlns:xsi'])
        print('\t@xsi:schemaLocation : ', values['ctex:externals']['@xsi:schemaLocation'])

        # date
        print('* date : ')
        print('\t$date : ', values['date']['$date'])

        # offset
        print('* offset : ', values['offset'])
         
        # path
        print('* path : ', values['path'])
         
        # channel
        print('* channel : ', values['channel'])


        print('======================================== end ==========================================')

#################################################################

def print_one_level_keys(file_name):
    """ JSON 에서 Level 1 의 Key Name 출력 """
    data = read_json_file(BASE_DIR, file_name)

    for key in data[0].keys():
        print(key)


print_one_level_keys(file_name)
print_all_items(file_name)

