import json
import os


BASE_DIR = 'C:\ysjung\KISA\data\\'
file_name = 'COLLECT_C0001.json'

def read_json_file(directory, file_name):
    """ 디렉토리 명과 파일 명을 입력 받아 해당 파일을 JSON 객체로 반환하는  함수 """
    with open(os.path.join(directory, file_name), 'r', encoding='UTF8') as data_file:
        data = json.load(data_file)
      ## loads()...?
    return data


def print_all_items(file_name):
    """" 파라메터로 받은 파일명의 파일을 분석해서 해당 내용을 모두 출력 """
    data = read_json_file(BASE_DIR, file_name)

    for values in data:
        print('======================================= start =========================================')
        # _id
        print('* _id : ')
        print('\t$oid : ', values['_id']['$oid'])

        # kisa:honeynet
        print('* kisa:honeynet: ')
        print('\tkisa:start: ')
        print('\t\tkisa:time : ', values['kisa:honeynet']['kisa:start']['kisa:time'])
        print('\t\tkisa:date : ', values['kisa:honeynet']['kisa:start']['kisa:date'])
        print('\tkisa:end: ')
        print('\t\tkisa:time : ', values['kisa:honeynet']['kisa:end']['kisa:time'])
        print('\t\tkisa:date : ', values['kisa:honeynet']['kisa:end']['kisa:date'])
        print('\t@xmlns:kisa: ', values['kisa:honeynet']['@xmlns:kisa'])
        print('\tkisa:attack: ', values['kisa:honeynet']['kisa:attack'])

    #    print(isinstance(samples, list))

        print('\tkisa:sample: ')
        print('\t\tkisa:md5: ', values['kisa:honeynet']['kisa:sample']['kisa:md5'])
        print('\t\tkisa:sha1: ', values['kisa:honeynet']['kisa:sample']['kisa:sha1'])
        print('\t\tkisa:ssdeep: ', values['kisa:honeynet']['kisa:sample']['kisa:ssdeep'])
        print('\t\tkisa:name: ', values['kisa:honeynet']['kisa:sample']['kisa:name'])
        print('\t\tkisa:report: ')
        print('\t\t\tkisa:item: ', values['kisa:honeynet']['kisa:sample']['kisa:report']['kisa:item'])
        print('\t\t\tkisa:caption: ', values['kisa:honeynet']['kisa:sample']['kisa:report']['kisa:caption'])
        print('\t\t\t@compress: ', values['kisa:honeynet']['kisa:sample']['kisa:report']['@compress'])
        print('\t\t\tkisa:path: ', values['kisa:honeynet']['kisa:sample']['kisa:report']['kisa:path'])

        print('\tkisa:source: ', values['kisa:honeynet']['kisa:source'])
        print('\tkisa:comment: ', values['kisa:honeynet']['kisa:comment'])
        print('\t@xsi:schemaLocation: ', values['kisa:honeynet']['@xsi:schemaLocation'])
        print('\tkisa:when: ')
        print('\t\tkisa:time: ', values['kisa:honeynet']['kisa:when']['kisa:time'])
        print('\t\tkisa:date: ', values['kisa:honeynet']['kisa:when']['kisa:date'])
        print('\t@xmlns:xsi: ', values['kisa:honeynet']['@xmlns:xsi'])
        print('\tkisa:report: ')
        print('\t\tkisa:item: ', values['kisa:honeynet']['kisa:report']['kisa:item'])
        print('\t\tkisa:caption: ', values['kisa:honeynet']['kisa:report']['kisa:caption'])
        print('\t\t@compress: ', values['kisa:honeynet']['kisa:report']['@compress'])
        print('\t\tkisa:path: ', values['kisa:honeynet']['kisa:report']['kisa:path'])
        print('\tkisa:method: ', values['kisa:honeynet']['kisa:method'])
        print('\tkisa:channel: ', values['kisa:honeynet']['kisa:channel'])

        # kisa:address 가 dict 또는 list 이므로 type 체크를 위해서 인스턴스 생ㅅ어
        addresses = values['kisa:honeynet']['kisa:address']

        # print(type(addresses))
        if isinstance(addresses, list):    # addresses 가 list 일 경우 반복문 처리
            for address in addresses:
                print('\tkisa:address: ')
                print('\t\tkisa:ip: ', address['kisa:ip'])
                print('\t\tkisa:icountry: ', address['kisa:icountry'])
                print('\t\tkisa:domain: ', address['kisa:domain'])
                print('\t\tkisa:url: ', address['kisa:url'])
                print('\t\tkisa:type: ', address['kisa:type'])
                print('\t\tkisa:dcountry: ', address['kisa:dcountry'])
                print('\t\tkisa:port: ', address['kisa:port'])
                print('\t\tkisa:protocol: ', address['kisa:protocol'])
        elif isinstance(addresses, dict):    # addresses 가 dict 일 경우 처리
            print('\tkisa:address: ')
            print('\t\tkisa:ip: ', addresses['kisa:ip'])
            print('\t\tkisa:icountry: ', addresses['kisa:icountry'])
            print('\t\tkisa:domain: ', addresses['kisa:domain'])
            print('\t\tkisa:url: ', addresses['kisa:url'])
            print('\t\tkisa:type: ', addresses['kisa:type'])
            print('\t\tkisa:dcountry: ', addresses['kisa:dcountry'])
            print('\t\tkisa:port: ', addresses['kisa:port'])
            print('\t\tkisa:protocol: ', addresses['kisa:protocol'])

        print('* path: ', values['path'])

        print('* offset: ', values['offset'])

        print('* date: ')

        print('\t$date: ', values['date']['$date'])

        print('* channel: ', values['channel'])

        print('* dbtime: ')
        print("\t$date: ", values['dbtime']['$date'])

        print('======================================== end ==========================================')


def print_one_level_keys(file_name):
    """ JSON 에서 Level 1 의 Key Name 출력 """
    data = read_json_file(BASE_DIR, file_name)

    for key in data[0].keys():
        print(key)


print_one_level_keys(file_name)
print_all_items(file_name)

