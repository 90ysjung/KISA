import json
import os

#BASE_DIR = os.path.dirname(os.path.abspath(__file__)) + '\\data'
#file_name = 'COLLECT_C0001.json'
#file_name = 'COLLECT_C8000.json'

directory = 'C:\ysjung\KISA\data' + '\\'
file_name = 'COLLECT_C8000_5.json'

""" 디렉토리 명과 파일 명을 입력 받아 해당 파일을 JSON 객체로 반환하는  함수 """
with open(os.path.join(directory, file_name), 'r', encoding='UTF8') as data_file:
    data = json.load(data_file)    ## loads()...?

print(type(data))

a0 = data[0]

r = a0.get('ctex:externals', 'N/A')

print(r)
print('')
print(type(r))

