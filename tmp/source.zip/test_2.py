﻿# -*- coding: utf-8 -*-

import konlpy
from konlpy.tag import Twitter
import nltk
import pickle
import numpy as np
import operator
from gensim import corpora, models
import gensim
import math
from collections import Counter
import os, re,copy
import sys
import io

twitter = Twitter()

file_path = "D:\py_test\data"
file_name = "A128.mlf"
file = (file_path + "\" + file_name)

print(file)


'''
#with io.open(file_path + "\" + file_name, 'r', encoding='utf8') as file:
with io.open("D:\py_test\data\A128.mlf", 'r', encoding='utf8') as file:
data = file.read()

#data = ("데이터 이전에$conrtibute$ 쓰던 SK사에서의//n&데이터인터넷& |999| 약정기간이 데이터 3다6되9어 ㅋㅋㅋ약정 되어")
'''
