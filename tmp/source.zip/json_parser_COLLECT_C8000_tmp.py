﻿###
### COLLECTION_C8000
###

def print_all_items(file_name):
### 파라메터로 받은 파일명의 파일을 분석해서 해당 내용을 모두 출력
    data = read_json_file(BASE_DIR, file_name)

    for values in data:
        print('======================================= start =========================================')
      # _id {1}
        print('* _id : ')
        print('\t$oid : ', values['_id']['$oid'])

      # ctex:externals {12}
        print('* ctex:externals : ')
        print('\tctex:version : ', values['ctex:externals']['ctex:version'])
        print('\tctex:title : ', values['ctex:externals']['ctex:title'])
        print('\tctex:when : ')
        print('\t\tctex:date : ', values['ctex:externals']['ctex:when']['ctex:date'])
        print('\t\tctex:time : ', values['ctex:externals']['ctex:when']['ctex:time'])
        print('\tctex:method : ', values['ctex:externals']['ctex:method'])
        print('\tctex:channel : ', values['ctex:externals']['ctex:channel'])
        print('\tctex:source : ', values['ctex:externals']['ctex:source'])
        print('\tctex:report : ', values['ctex:externals']['ctex:report'])
        print('\t\tctex:path : ', values['ctex:externals']['ctex:report']['ctex:path'])
        print('\t\tctex:item : ', values['ctex:externals']['ctex:report']['ctex:item'])
        print('\t\tctex:caption : ', values['ctex:externals']['ctex:report']['ctex:caption'])
        print('\t\tctex:@compress : ', values['ctex:externals']['ctex:report']['ctex:@compress'])
        print('\tctex:comment : ', values['ctex:externals']['ctex:comment'])
        print('\tctex:external   : ', values['ctex:externals']['ctex:external'])
'''
### 리스트로 들어 옴[34]   print('\t\t', values['ctex:externals']['ctex:external'][''])

        print('\t@xmlns:ctex : ', values['ctex:externals']['@xmlns:ctex'])
        print('\t@xmlns:xsi : ', values['ctex:externals']['@xmlns:xsi'])
        print('\t@xsi:schemaLocation : ', values['ctex:externals']['@xsi:schemaLocation'])
'''
'''
ctex:version  : 1.0
ctex:title  : 2014-08-07-000000-SKInfosec-Report
ctex:when   {2}
ctex:method : system
ctex:channel  : infosec
ctex:source : infosec
ctex:report   {4}
ctex:comment  :
ctex:external   [34]
@xmlns:ctex : http://ctex.krcert.or.kr
@xmlns:xsi  : http://www.w3.org/2001/XMLSchema-instance
@xsi:schemaLocation : http://ctex.krcert.or.kr collect.xsd
'''

'''
      # date
        print('* date : ')
        print('\t$date : ', values['date']['$date'])

      # offset
        print('* offset : ',values['offset'])

      # path
        print('* path : ', values['path'])

      # channel
        print('* channel '), values['channel']['channel'])
'''

        print('======================================== end ==========================================')

#################################################################

