﻿import csv
import json
import os

BASE_DIR = 'C:\ysjung\KISA\data' + '\\'
file_name = 'COLLECT_C8000_5.json'

with open(os.path.join(BASE_DIR, file_name), 'r', encoding='UTF8') as data_file:
    data = json.load(data_file)    ## loads() or load() ...?

#data = data[0]
#print(type(data))   # dict

r = [] 
n = 'N/A'
for x in data:
    rr = []

    id = (x["_id"]["$oid"])
    rr.append(id)
    
    external = (x["ctex:externals"]["ctex:external"])
    for ext in external:                                 # 리스트를 dict으로..
        rrr = []
        #print(type(ext))                                            # dict 
        
        address = ext["ctex:address"]   # 리스트를 dict으로..
        #print(type(address))                                        # dict 

        for add in address: 
            rrrr = []
            #print(type(add))                                        # dict 
            ad = add.get("ctex:address", n)      #ctex:address
            if ad == n:
                rrrr.append(n)
            else:
                domain = ad.get("ctex:domain", n)          #ctex:address.ctex:domain
                if domain == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:domain"])
                dcountry = ad.get("ctex:dcountry", n)          #ctex:address.ctex:dcountry
                if dcountry == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:dcountry"])        
                ip = ad.get("ctex:ip", n)          #ctex:address.ctex:ip
                if ip == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:ip"])
                icountry = ad.get("ctex:icountry", n)          #ctex:address.ctex:icountry
                if icountry == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:icountry"])
                protocol = ad.get("ctex:protocol", n)          #ctex:address.ctex:protocol
                if protocol == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:protocol"])                    
                port = ad.get("ctex:port", n)          #ctex:address.ctex:port
                if port == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:port"])
                url = ad.get("ctex:url", n)          #ctex:address.ctex:url
                if url == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:url"])
                type = ad.get("ctex:type", n)          #ctex:address.ctex:type
                if type == n:
                    rrrr.append(n)
                else:
                    rrrr.append(add["ctex:address"]["ctex:type"])
                rrr.append(rrrr)                                                        
            rr.append(rrr)
        r.append(rr)

#print(r)
print(len(r), "rows")

f = csv.writer(open('C8000_level_e.csv', 'w', newline= ''))

# Write CSV Header 총 9개 필
f.writerow(["id","external.ctex:domain", "external.ctex:dcountry", "external.ctex:ip",
            "external.ctex:icountry", "external.ctex:protocol", "external.ctex:port", 
            "external.ctex:url", "external.ctex:type"])

for i in r:
    f.writerow(i)


####################################
#id
#ctex:address.ctex:domain
#ctex:address.ctex:dcountry
#ctex:address.ctex:ip
#ctex:address.ctex:icountry
#ctex:address.ctex:protocol
#ctex:address.ctex:port
#ctex:address.ctex:url
#ctex:address.ctex:type
####################################
