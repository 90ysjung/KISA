﻿# json.decoder.JSONDecodeError: Extra data: line 2 column 1 (char 1543)
# mongoexport 에서 --jsonArray 옵션으로 내리면 위 에러 없음 ex) [{},{},{},...]

### 파이썬으로 json 파일을 읽어온다
### 1 collection 당 1 json 으로 내려온다
##################################
### key 값을 추출한다
##################################
import json 
from pprint import pprint
from collections import OrderedDict   # object_pairs_hook=OrderedDict 는 초기 json 순서대로 찍는다

path = 'C:\ysjung\KISA\data'
input_file = 'COLLECT_C0023.json'

json_data = open(path + '\\' + input_file, encoding='utf-8').read() # str type
doc = json.loads(json_data, object_pairs_hook=OrderedDict)          # object_pairs_hook=OrderedDict

#print(type(doc))           # list로 생성된다

element = len(list(doc))    # mongodb 에서 document 개수
print('\n' + 'Element count: ' + str(element) + '\n')

key = list((doc[0]))        # key = (doc[0].keys())) 와 차이점은...?

### document 별로 key 개수가 다르다
### document 별로 key 값 뽑아올 것

print(key)                  # key 값 출력
print('')

count = 0
doc_keys = {}
while count <= element: 
    doc_keys[count] = key
    pprint(doc_keys)
    count += 1


'''
count = 0 
while count <= element:
    for i, key in enumerate(list(doc[count])):
        if i > 0:
             print(str(i) + ', ' + key)
    count += 1 

print(count)
'''

'''
print("걸그룹 %s의 멤버는 다음과 같습니다" % data['name'], end='\n\n')

print("멤버: ", end='')
for i, name in enumerate(data['members']):    # 리스트는 index 로 잡아온다
    if i > 0:
         print(", ", end='')
    print(name, end='')

print("\n\n 앨범 list : ", end='\n')
for album, title in data['albums'].items():   # 집합은 key, value 로 잡아온다
    print(" %s: %s " %(album, title))



'''