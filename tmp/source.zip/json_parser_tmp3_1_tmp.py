import json
import os

#BASE_DIR = os.path.dirname(os.path.abspath(__file__)) + '\\data'
#file_name = 'COLLECT_C0001.json'
#file_name = 'COLLECT_C8000.json'

directory = 'C:\ysjung\KISA\data' + '\\'
file_name = 'COLLECT_C8000_5.json'

""" 디렉토리 명과 파일 명을 입력 받아 해당 파일을 JSON 객체로 반환하는  함수 """
with open(os.path.join(directory, file_name), 'r', encoding='UTF8') as data_file:
    data = json.load(data_file)    ## loads()...?

"""
print(type(data))

a0 = data[0]

r = a0.get('ctex:externals', 'N/A')

#print(r)
print('')
print(type(r))


    for i, values in enumerate(data):
        print('======================================= start =========================================')
        print('### row_num : ', i, ' ###')
        # _id {1}
        print('* _id : ')
        print('\t$oid : ', values['_id']['$oid'])

        # ctex:externals  {12}
        # ctex:externals 값을 읽어들이기 위해서 Instance 생성 후 Key 존재 유/무 체크
        externals = values.get('ctex:externals', 'N/A')
        if externals == 'N/A':  # Key 가 존재하지 않을 경우
            print('* ctex:externals : ', externals)
        else:                    # Key 가 존재할 경우
            print('* ctex:externals : ')
            print('\tctex:version : ', externals.get('ctex:version', 'N/A'))
            print('\tctex:title : ', externals.get('ctex:title', 'N/A'))

            # ctex:externals / ctex:when
            ctex_when = externals.get('ctex:when', 'N/A')
            if ctex_when == 'N/A':
                print('\tctex_when : ', ctex_when)
            else:
                print('\tctex_when : ')
                print('\t\tctex:date : ', ctex_when.get('ctex:date', 'N/A'))
                print('\t\tctex:time : ', ctex_when.get('ctex:time', 'N/A'))

            print('\tctex:method : ', externals.get('ctex:method', 'N/A'))
            print('\tctex:channel : ', externals.get('ctex:channel', 'N/A'))
            print('\tctex:source : ', externals.get('ctex:source', 'N/A'))

            # ctex:externals / ctex:report
            ctex_report = externals.get('ctex:report', 'N/A')
            if ctex_report == 'N/A':
                print('\tctex:report : ', ctex_report)
            else:
                print('\tctex:report : ')
                print('\t\tctex:path : ', ctex_report.get('ctex:path', 'N/A'))
                print('\t\tctex:item : ', ctex_report.get('ctex:item', 'N/A'))
                print('\t\tctex:caption : ', ctex_report.get('ctex:caption', 'N/A'))
                print('\t\t@compress : ', ctex_report.get('@compress', 'N/A'))

            print('\tctex:comment : ', externals.get('ctex:comment', 'N/A'))

            # ctex:externals / ctex:external
            ctex_external = externals.get('ctex:external', 'N/A')
            if ctex_external == 'N/A':
                print('\tctex:external : ', ctex_external)
            elif isinstance(ctex_external, list):  # external 가 List 인지 Dictionary 인지 체크 >> List 일 경우 반복처리
                for ctex_external_value in ctex_external:
                    print('\tctex:external : ')

                    # ctex:externals / ctex:external / ctex:when
                    ctex_when = ctex_external_value.get('ctex:when', 'N/A')
                    if ctex_when == 'N/A':
                        print('\t\tctex:when : ', 'N/A')
                    else:
                        print('\t\tctex:when : ')
                        print('\t\t\tctex:date : ', ctex_when.get('ctex:date', 'N/A'))
                        print('\t\t\tctex:time : ', ctex_when.get('ctex:time', 'N/A'))

                    print('\t\tctex:method : ', ctex_external_value.get('ctex:method', 'N/A'))
                    print('\t\tctex:channel : ', ctex_external_value.get('ctex:channel', 'N/A'))
                    print('\t\tctex:source : ', ctex_external_value.get('ctex:source', 'N/A'))

                    # ctex:externals / ctex:external / ctex:report
                    ctex_report = ctex_external_value.get('ctex:report', 'N/A')
                    if ctex_report == 'N/A':
                        print('\t\tctex:report : ', ctex_report)
                    else:
                        print('\t\tctex:report : ')
                        print('\t\t\tctex:path : ', ctex_report.get('ctex:path', 'N/A'))
                        print('\t\t\tctex:item : ', ctex_report.get('ctex:item', 'N/A'))
                        print('\t\t\tctex:caption : ', ctex_report.get('ctex:caption', 'N/A'))

                    print('\t\tctex:comment : ', ctex_external_value.get('ctex:comment', 'N/A'))

                    # ctex:externals / ctex:external / ctex:address
                    ctex_address = ctex_external_value.get('ctex:address', 'N/A')
                    if ctex_address == 'N/A':
                        print('\t\tctex:address : ', ctex_address)
                    elif isinstance(ctex_address, list):  # ctex:address 가 List 일경우 처리
                        for address_data in ctex_address:
                            print('\t\tctex:address : ')
                            print('\t\t\tctex:domain : ', address_data.get('ctex:domain', 'N/A'))
                            print('\t\t\tctex:dcountry : ', address_data.get('ctex:dcountry', 'N/A'))
                            print('\t\t\tctex:ip : ', address_data.get('ctex:ip', 'N/A'))
                            print('\t\t\tctex:icountry : ', address_data.get('ctex:icountry', 'N/A'))
                            print('\t\t\tctex:protocol : ', address_data.get('ctex:protocol', 'N/A'))
                            print('\t\t\tctex:port : ', address_data.get('ctex:port', 'N/A'))
                            print('\t\t\tctex:url : ', address_data.get('ctex:url', 'N/A'))
                            print('\t\t\tctex:type : ', address_data.get('ctex:type', 'N/A'))
                            print('\t\t\tctex:comment : ', address_data.get('ctex:comment', 'N/A'))
                    else:                                 # ctex:address 가 Dictionary 일 경우 처리
                        print('\t\tctex:address : ')
                        print('\t\t\tctex:domain : ', ctex_address.get('ctex:domain', 'N/A'))
                        print('\t\t\tctex:dcountry : ', ctex_address.get('ctex:dcountry', 'N/A'))
                        print('\t\t\tctex:ip : ', ctex_address.get('ctex:ip', 'N/A'))
                        print('\t\t\tctex:icountry : ', ctex_address.get('ctex:icountry', 'N/A'))
                        print('\t\t\tctex:protocol : ', ctex_address.get('ctex:protocol', 'N/A'))
                        print('\t\t\tctex:port : ', ctex_address.get('ctex:port', 'N/A'))
                        print('\t\t\tctex:url : ', ctex_address.get('ctex:url', 'N/A'))
                        print('\t\t\tctex:type : ', ctex_address.get('ctex:type', 'N/A'))
                        print('\t\t\tctex:comment : ', ctex_address.get('ctex:comment', 'N/A'))

                    # ctex:externals / ctex:external / ctex:sample
                    ctex_sample = ctex_external_value.get('ctex:sample', 'N/A')
                    if ctex_sample == 'N/A':
                        print('\t\tctex:sample : ', ctex_sample)
                    else:
                        print('\t\tctex:sample : ')
                        print('\t\t\tctex_md5 : ', ctex_sample.get('ctex:md5', 'N/A'))
                        print('\t\t\tctex_sha1 : ', ctex_sample.get('ctex:sha1', 'N/A'))
                        print('\t\t\tctex:ssdeep : ', ctex_sample.get('ctex:ssdeep', 'N/A'))

                        # ctex:externals / ctex:external / ctex_sample / ctex_report
                        ctex_report = ctex_sample.get('ctex_report', 'N/A')
                        if ctex_report == 'N/A':
                            print('\t\t\tctex:report : ', ctex_report)
                        else:
                            print('\t\t\tctex_report : ')
                            print('\t\t\t\tctex:path : ', ctex_report.get('ctex:path', 'N/A'))
                            print('\t\t\t\tctex:item : ', ctex_report.get('ctex:item', 'N/A'))
                            print('\t\t\t\tctex:caption : ', ctex_report.get('ctex:caption', 'N/A'))
                            print('\t\t\t\t@compress : ', ctex_report.get('@compress', 'N/A'))

                        print('\t\t\tctex:name : ', ctex_sample.get('ctex:name', 'N/A'))
                        print('\t\t\tctex:type : ', ctex_sample.get('ctex:type', 'N/A'))
                        print('\t\t\tctex:comment : ', ctex_sample.get('ctex:comment', 'N/A'))

                    # ctex:externals / ctex:external / ctex:message
                    ctex_message = ctex_external_value.get('ctex:message', 'N/A')
                    if ctex_message == 'N/A':
                        print('\t\tctex:message : ', ctex_message)
                    else:
                        print('\t\tctex:message : ')
                        print('\t\t\tctex:subject : ', ctex_message.get('ctex:subject', 'N/A'))
                        print('\t\t\tctex:from : ', ctex_message.get('ctex:from', 'N/A'))
                        print('\t\t\tctex:to : ', ctex_message.get('ctex:to', 'N/A'))

                        # ctex:externals / ctex:external / ctex:message / ctex:sent
                        ctex_sent = ctex_message.get('ctex:sent', 'N/A')
                        if ctex_sent == 'N/A':
                            print('\t\t\tctex:sent : ', ctex_sent)
                        else:
                            print('\t\t\tctex:sent : ')
                            print('\t\t\t\tctex:date : ', ctex_sent.get('ctex:date', 'N/A'))
                            print('\t\t\t\tctex:time : ', ctex_sent.get('ctex:time', 'N/A'))

                        # ctex:externals / ctex:external / ctex:message / ctex:sent
                        ctex_received = ctex_message.get('ctex:received', 'N/A')
                        if ctex_received == 'N/A':
                            print('\t\t\tctex:received : ', ctex_received)
                        else:
                            print('\t\t\tctex:received : ')
                            print('\t\t\t\tctex:date : ', ctex_received.get('ctex:date', 'N/A'))
                            print('\t\t\t\tctex:time : ', ctex_received.get('ctex:time', 'N/A'))

                        print('\t\t\tctex:content : ', ctex_message.get('ctex:content', 'N/A'))

                        # ctex:externals / ctex:external / ctex:message / ctex:attached
                        ctex_attached = ctex_message.get('ctex:attached', 'N/A')
                        if ctex_attached == 'N/A':
                            print('\t\t\tctex:attached : ', ctex_attached)
                        else:
                            print('\t\t\tctex:attached : ')
                            print('\t\t\t\tctex:md5 : ', ctex_attached.get('ctex:md5', 'N/A'))
                            print('\t\t\t\tctex:sh1 : ', ctex_attached.get('ctex:sh1', 'N/A'))
                            print('\t\t\t\tctex:ssdeep : ', ctex_attached.get('ctex:ssdeep', 'N/A'))

                            ctex_report = ctex_attached.get('ctex_report', 'N/A')
                            if ctex_report == 'N/A':
                                print('\t\t\t\tctex:report : ', ctex_report)
                            else:
                                print('\t\t\t\tctex_report : ')
                                print('\t\t\t\t\tctex:path : ', ctex_report.get('ctex:path', 'N/A'))
                                print('\t\t\t\t\tctex:item : ', ctex_report.get('ctex:item', 'N/A'))
                                print('\t\t\t\t\tctex:caption : ', ctex_report.get('ctex:caption', 'N/A'))

                        print('\t\t\tctex:comment : ', ctex_message.get('ctex:comment', 'N/A'))

            # ctex:externals
            print('\t@xmlns:ctex : ', externals.get('@xmlns:ctex', 'N/A'))
            print('\t@xmlns:xsi : ', externals.get('@xmlns:xsi', 'N/A'))
            print('\t@xsi:schemaLocation : ', externals.get('@xsi:schemaLocation', 'N/A'))

        # date {1}
        ctex_date = values.get('date', 'N/A')
        if ctex_date == 'N/A':
            print('* date : ', ctex_date)
        else:
            print('* date : ')
            print('\t$date : ', ctex_date.get('$date', 'N/A'))

        # offset ... {1}
        print('* offset : ', values.get('offset', 'N/A'))
        print('* path : ', values.get('path', 'N/A'))
        print('* channel : ', values.get('channel', 'N/A'))

        print('======================================== end ==========================================')
"""