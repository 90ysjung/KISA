# input_list 를 function 화 한다
# input_list 를 import 한다

import json
import os
from collections import OrderedDict
from pprint import pprint

path = 'D:\py_test\source'
files = os.listdir(path)

#print(files, end='')
#print('')

for i in files:
   input_list = []
   if '.json' in i:
      input_list.append(path + '\\' + i)
      print(input_list)

##

for i, in input_list: 
   
   with open(input_list, encoding="utf-8") as data_file:
    data = json.load(data_file, object_pairs_hook=OrderedDict)

print(list(data))
print('')
pprint(data)
print('')
print(data)

'''
print("걸그룹 %s의 멤버는 다음과 같습니다" % data['name'], end='\n\n')

print("멤버: ", end='')
for i, name in enumerate(data['members']):    # 리스트는 index 로 잡아온다
    if i > 0:
         print(", ", end='')
    print(name, end='')

print("\n\n 앨범 list : ", end='\n')
for album, title in data['albums'].items():   # 집합은 key, value 로 잡아온다
    print(" %s: %s " %(album, title))


'''