import time
import timeit
from functools import wraps


def runtime(func):
    @wraps(func)
    def function_timer(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        # print(result)
        end_time = time.time()
        print('Total Time Running %s: %s seconds' % (func.__name__, str(round((end_time - start_time), 3))))

        return result
    return function_timer


@runtime
def odd_sum_for(n):
    result = 0
    # n = int(input("input the number : "))

    for i in range(0, n + 1):
        if n > 1000000:
            return "1000과 같거나 작은 수를 입력하세요!"
        elif not i % 2 == 0:
            result += i
    return "1부터 {n}까지 홀수의 합 : {result}".format(n=n, result=result)


# runtime(odd_sum_for(100))
# print(timeit.timeit(stmt="odd_sum_for(10)", setup="from __main__ import odd_sum_for"))
odd_sum_for(99999)