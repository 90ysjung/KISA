from datetime import datetime
from zipfile import ZipFile

from dga_generators import banjori, corebot, cryptolocker, dircrypt, kraken, lockyv2, pykspa, qakbot, ramdo, simda

import os
import io
import requests
import tldextract
import random
import pickle

TOP_1M_URL = 'http://s3.amazonaws.com/alexa-static/top-1m.csv.zip'
DATA_DIRECTORY = os.path.dirname(os.path.abspath(__file__)) + '\\data'
# DATA_DIRECTORY = os.path.dirname(os.pardir)
DATA_FILE = 'train_data.pkl'

# print(DATA_DIRECTORY)


def get_top_1m_url(num, address=TOP_1M_URL, filename='top-1m.csv'):
    req = requests.get(address)
    zfile = ZipFile(io.BytesIO(req.content))
    file = zfile.read(filename)

    t_data = file.decode()
    t_data = t_data.encode('ascii', errors='ignore')
    t_data = t_data.decode().split()[:num]

    result = [tldextract.extract(url_string.split(',')[1]).domain for url_string in t_data]
    # result = [url_string.split(',')[1] for url_string in t_data]

    return result


def get_dga_url(dga_num=10000):

    domains = []
    labels = []

    # 1. We use some arbitrary seeds to create domains with banjori
    banjori_seeds = ['somestring', 'firetruck', 'bulldozer', 'airplane', 'racecar',
                     'apartment', 'laptop', 'laptopcomp', 'malwareisbad', 'crazytrain',
                     'thepolice', 'fivemonkeys', 'hockey', 'football', 'baseball',
                     'basketball', 'trackandfield', 'fieldhockey', 'softball', 'redferrari',
                     'blackcheverolet', 'yellowelcamino', 'blueporsche', 'redfordf150',
                     'purplebmw330i', 'subarulegacy', 'hondacivic', 'toyotaprius',
                     'sidewalk', 'pavement', 'stopsign', 'trafficlight', 'turnlane',
                     'passinglane', 'trafficjam', 'airport', 'runway', 'baggageclaim',
                     'passengerjet', 'delta1008', 'american765', 'united8765', 'southwest3456',
                     'albuquerque', 'sanfrancisco', 'sandiego', 'losangeles', 'newyork',
                     'atlanta', 'portland', 'seattle', 'washingtondc']

    segs_size = max(1, int(dga_num / len(banjori_seeds)))

    for banjori_seed in banjori_seeds:
        domains += banjori.generate_domains(segs_size, banjori_seed)
        labels += ['banjori'] * segs_size

    # 2. corebot
    domains += corebot.generate_domains(dga_num)
    labels += ['corebot'] * dga_num

    # 3. Create different length domains using cryptolocker
    crypto_lengths = range(8, 32)
    segs_size = max(1, int(dga_num / len(crypto_lengths)))

    for crypto_length in crypto_lengths:
        domains += cryptolocker.generate_domains(segs_size, seed_num=random.randint(1, 1000000), length=crypto_length)
        labels += ['cryptolocker'] * segs_size

    # 4. dircrypt
    domains += dircrypt.generate_domains(dga_num)
    labels += ['dircrypt'] * dga_num

    # 5. generate kraken and divide between configs
    kraken_to_gen = max(1, int(dga_num / 2))

    domains += kraken.generate_domains(kraken_to_gen, datetime(2016, 1, 1), 'a', 3)
    labels += ['kraken'] * kraken_to_gen

    domains += kraken.generate_domains(kraken_to_gen, datetime(2016, 1, 1), 'b', 3)
    labels += ['kraken'] * kraken_to_gen

    # 6. generate locky and divide between configs
    locky_gen = max(1, int(dga_num / 11))
    for i in range(1, 12):
        domains += lockyv2.generate_domains(locky_gen, config=i)
        labels += ['locky'] * locky_gen

    # 7. generate pyskpa domains
    domains += pykspa.generate_domains(dga_num, datetime(2016, 1, 1))
    labels += ['pykspa'] * dga_num

    # 8. generate qakbot
    domains += qakbot.generate_domains(dga_num, tlds=[])
    labels += ['qakbot'] * dga_num

    # 9. ramdo divided over different lengths
    ramdo_lengths = range(8, 32)
    segs_size = max(1, int(dga_num / len(ramdo_lengths)))
    for ramdo_length in ramdo_lengths:
        domains += ramdo.generate_domains(segs_size, seed_num=random.randint(1, 1000000), length=ramdo_length)
        labels += ['ramdo'] * segs_size

    # 10. simda
    simda_lengths = range(8, 32)
    segs_size = max(1, int(dga_num / len(simda_lengths)))
    for simda_length in simda_lengths:
        domains += simda.generate_domains(segs_size, length=simda_length, tld=None, base=random.randint(2, 2**32))
        labels += ['simda'] * segs_size

    return domains, labels


def generate_data(force=False):
    if force or (not os.path.isfile(os.path.join(DATA_DIRECTORY, DATA_FILE))):
        domains, labels = get_dga_url(10000)

        domains += get_top_1m_url(len(domains))
        labels += ['benign'] * len(domains)

        pickle.dump(zip(labels, domains), open(os.path.join(DATA_DIRECTORY, DATA_FILE), 'wb'))


def get_data(force=False):
    generate_data()

    # tmp_data = pickle.load(open(os.path.join(DATA_DIRECTORY, DATA_FILE), 'rb'))
    # labels = [x[0] for x in tmp_data]

    # print(labels)
    return pickle.load(open(os.path.join(DATA_DIRECTORY, DATA_FILE), 'rb'))

# get_dga_url(10000)
# get_top_1m_url(10000)

# get_data()